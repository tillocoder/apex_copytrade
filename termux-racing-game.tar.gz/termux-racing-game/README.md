# 🏎️ APEX SPEED 3D - Termux Multiplayer Racing Game

Termux (Android) serverlari uchun maxsus optimallashtirilgan, o'ta yengil (**ultra-lightweight**) real-time 3D multiplayer poyga o'yini.

---

## ⚡ Asosiy Afzalliklari va Xususiyatlari

1. **Brauzerda ishlaydi**: Hech qanday ilova yoki plugin o'rnatish shart emas. Har qanday telefon (Chrome, Safari) yoki kompyuter brauzerida ishlaydi.
2. **2 kishilik Real-Time Multiplayer**:
   - Lobbyda online foydalanuvchilar ro'yxati ko'rinadi.
   - Do'stingizga **⚔️ Challenge** tugmasi orqali taklif yuborasiz (15 soniyalik modal).
   - Do'stingiz qabul qilishi bilan ikkalangiz bir vaqtda 3D trassaga tushasiz.
3. **Synchronized Race Flow**:
   - 3 → 2 → 1 → **GO!** avtoritativ start sanoqi (sanoq paytida boshqaruv qulflanadi).
   - 2 davrali qizg'in duel.
   - Trassa bo'ylab 12 ta nazorat nuqtalari (checkpoints) orqali adolatli poyga va burchaklarni kesib o'tishning (cheat) oldi olingan.
   - Finish va g'olib ekrani: Natijalar, umumiy vaqt va eng yaxshi davra (best lap).
   - **Rematch tizimi**: Ikkala o'yinchi ham Rematch tugmasini bosishi bilan avtomatik qayta start oladi.
4. **Termux uchun O'ta Kam Resurs Sarfi**:
   - **RAM**: ~25 MB - 35 MB Node.js xotirasi.
   - **CPU**: 0.05% - 0.2% (Serverda og'ir fizika yoki 3D rendering hisoblanmaydi!).
   - Fizika to'liq client-side (brauzerda) ishlaydi, server faqat tezkor holat almashinuvi (state relay) va matchmaking bilan shug'ullanadi.
   - C++ kompilyatsiyasi yoki `node-gyp` talab qilmaydi — faqat bitta sof JavaScript `ws` moduli.
5. **Yuqori Grafika va Ovoz**:
   - Low-poly sport avtomobili (chassis, spoyler, fara nurlari, tormoz chiroqlari, buriluvchi va aylanuvchi g'ildiraklar, drift tutuni).
   - Web Audio API orqali procedural ovoz (dvigatel shovqini, drift chiyillashi, start signallari) — birorta audio fayl yuklab olinmaydi, 0 KB yuklama!
   - 2D jonli minimap (trassa va ikkala mashina nuqtalari).
   - Ping (ms), FPS (60) va Termux server holati indikatorlari.
6. **Desktop va Mobil Boshqaruv**:
   - **Kompyuterda**: WASD yoki Yo'nalish tugmalari (▲ ▼ ◀ ▶), Bo'shliq (Drift/Handbrake), R (Trassaga qayta qo'yish).
   - **Telefonda**: Ekranda sensorli tugmalar (Gaz, Tormoz, Chap, O'ng, Drift, Reset).

---

## 📁 Loyiha Tuzilmasi

```text
termux-racing-game/
├── server.js              # Ultra-yengil HTTP + WebSocket server
├── package.json           # Faqat bitta dependency: "ws"
├── ecosystem.config.js    # PM2 orqali Termuxda 24/7 orqa fonda yurgizish
├── start.sh               # Tezkor ishga tushirish skripti
├── install-termux.sh      # 1-klikli Termux o'rnatish skripti
├── nginx.conf             # Nginx Reverse Proxy konfiguratsiyasi
└── public/
    ├── index.html         # Asosiy HTML (Lobby, HUD, Modallar, Touch UI)
    ├── css/
    │   └── style.css      # Cyberpunk & Glassmorphism dizayn
    └── js/
        ├── lib/
        │   └── three.min.js  # Offline Three.js (Termuxdan to'g'ridan-to'g'ri beriladi)
        ├── audio.js       # Web Audio API protsessual tovush generatori
        ├── input.js       # Klaviatura va sensorli tugmalar boshqaruvi
        ├── car.js         # 3D avtomobil modeli va arkada fizikasi
        ├── track.js       # 3D trassa, bordyurlar, minimap va chekpointlar
        ├── network.js     # WebSocket mijoz va ping o'lchagich
        └── game.js        # Three.js render tsikli, kamera va UI boshqaruvi
```

---

## 🚀 Termux Serverga O'rnatish va Ishga Tushirish

### 1-Qadam: Termux'ga yuklash
Loyiha papkasini (`termux-racing-game`) Termux serveringizga nusxalang (masalan, git, scp yoki tar/zip orqali):
```bash
cd termux-racing-game
```

### 2-Qadam: O'rnatish
Agar Node.js bo'lmasa yoki yangi o'rnatayotgan bo'lsangiz:
```bash
chmod +x install-termux.sh start.sh
./install-termux.sh
```

Yoki qo'lda:
```bash
pkg install nodejs-lts -y
npm install --omit=dev
```

### 3-Qadam: Ishga tushirish
Standart tarzda **5050** portda ishga tushadi:
```bash
./start.sh
# yoki
node server.js
```

Agar boshqa port tanlamoqchi bo'lsangiz:
```bash
PORT=4000 node server.js
```

### 4-Qadam: Orqa fonda (24/7 PM2) ishlatish
Termux ilovasi yopilganda ham server to'xtab qolmasligi uchun:
```bash
npm install -g pm2
pm2 start ecosystem.config.js
pm2 save
```
Holatni tekshirish:
```bash
pm2 status
pm2 logs apex-speed-3d
```

---

## 🌐 Brauzer orqali Kirish va O'ynash

1. **Mahalliy Wi-Fi / Hotspot orqali**:
   - Termux serverining IP manzilini bilish uchun: `ifconfig` (masalan, `192.168.1.15`).
   - Ikkala telefon ham bir xil Wi-Fi tarmog'iga ulangan bo'lsa:
     `http://192.168.1.15:5050`
   - **Internet bo'lmasa ham ishlaydi** — barcha 3D kutubxonalar va tovushlar to'liq oflayn yuklanadi!

2. **Cloudflare Tunnel orqali (Tashqi internet uchun eng oson yo'l)**:
   ```bash
   pkg install cloudflared -y
   cloudflared tunnel --url http://localhost:5050
   ```
   Sizga `https://tasodifiy-nom.trycloudflare.com` havolasini beradi. Do'stingizga shu havolani berasiz!

3. **Nginx Reverse Proxy orqali (O'z domeningiz bo'lsa)**:
   Mavjud domeningiz yoki subdomeningiz uchun `nginx.conf` faylidagi sozlamani Nginx konfiguratsiyasiga qo'shing:
   ```nginx
   location / {
       proxy_pass http://127.0.0.1:5050;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection "upgrade";
       proxy_set_header Host $host;
   }
   ```
   So'ng `nginx -s reload` qiling.

---

## 🎮 O'yin Jarayoni

1. Brauzerda sahifani ochasiz. Taxallus (ism) avtomatik saqlanadi (`localStorage`).
2. Do'stingiz ham xuddi shu havolani ochadi.
3. Lobbyda ikkovingiz ham paydo bo'lasiz.
4. Do'stingiz yonidagi **⚔️ Challenge** tugmasini bosing.
5. Do'stingiz telefonida chiroyli taklif modali chiqadi. U **QABUL QILISH** tugmasini bosadi.
6. 3D poyga maydoni yuklanadi, **3 → 2 → 1 → GO!** sanoq tugagach poyga boshlanadi!
7. 2 davra tugagach g'olib e'lon qilinadi va **Rematch** tugmasi orqali cheksiz davom ettirish mumkin.
