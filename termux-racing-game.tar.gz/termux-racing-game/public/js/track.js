/**
 * APEX SPEED 3D - Procedural 3D Race Circuit & Minimap
 * Catmull-Rom track generation, curb rumble strips, guardrails, start gantry, and checkpoints
 */

class RaceTrack {
  constructor(scene) {
    this.scene = scene;
    this.trackGroup = new THREE.Group();
    this.scene.add(this.trackGroup);

    this.roadWidth = 14;
    this.checkpoints = [];
    this.startPositions = [];

    // Define 3D track curve points (Exciting circuit layout with chicane, hairpins, and straight)
    this.curvePoints = [
      new THREE.Vector3(0, 0, 0),        // Start / Finish straight
      new THREE.Vector3(0, 0, 80),       // Main straight end
      new THREE.Vector3(30, 0, 130),     // Turn 1 sweeping right
      new THREE.Vector3(80, 0, 140),     // Turn 2
      new THREE.Vector3(120, 0, 100),    // Hairpin exit
      new THREE.Vector3(110, 0, 30),     // Short straight
      new THREE.Vector3(140, 0, -30),    // Chicane entry right
      new THREE.Vector3(110, 0, -80),    // Chicane exit left
      new THREE.Vector3(50, 0, -120),    // Fast sweeper
      new THREE.Vector3(-40, 0, -110),   // Turn onto back straight
      new THREE.Vector3(-90, 0, -60),    // Back sweeper
      new THREE.Vector3(-80, 0, 10),     // Final hairpin entry
      new THREE.Vector3(-40, 0, 30),     // Final turn onto main straight
      new THREE.Vector3(-10, 0, -10)     // Final straight alignment
    ];

    this.curve = new THREE.CatmullRomCurve3(this.curvePoints, true, 'centripetal');
    
    // Generate track elements
    this.buildRoad();
    this.buildEnvironment();
    this.buildStartGantry();
    this.generateCheckpoints();
    this.buildNitroPads();
    this.buildObstacles();
    this.buildOilSlicks();
  }

  buildRoad() {
    const numSegments = 300;
    const roadPoints = this.curve.getSpacedPoints(numSegments);
    
    const roadVertices = [];
    const roadUvs = [];
    const roadIndices = [];

    const curbLVertices = [];
    const curbRVertices = [];
    const curbIndices = [];

    const halfWidth = this.roadWidth / 2;
    const curbWidth = 1.0;

    for (let i = 0; i <= numSegments; i++) {
      const u = i / numSegments;
      const pt = roadPoints[i % numSegments];
      const tangent = this.curve.getTangentAt(u).normalize();
      const up = new THREE.Vector3(0, 1, 0);
      const normal = new THREE.Vector3().crossVectors(tangent, up).normalize();

      // Road Left & Right edges
      const left = new THREE.Vector3().copy(pt).addScaledVector(normal, -halfWidth);
      const right = new THREE.Vector3().copy(pt).addScaledVector(normal, halfWidth);

      // Elevated slightly above terrain
      left.y = 0.05;
      right.y = 0.05;

      roadVertices.push(left.x, left.y, left.z);
      roadVertices.push(right.x, right.y, right.z);

      roadUvs.push(0, u * 50);
      roadUvs.push(1, u * 50);

      // Kerbs (Rumble strips)
      const curbLeftOuter = new THREE.Vector3().copy(left).addScaledVector(normal, -curbWidth);
      const curbRightOuter = new THREE.Vector3().copy(right).addScaledVector(normal, curbWidth);
      curbLeftOuter.y = 0.12;
      curbRightOuter.y = 0.12;

      const idxL = i * 2;
      curbLVertices.push(curbLeftOuter.x, curbLeftOuter.y, curbLeftOuter.z);
      curbLVertices.push(left.x, left.y, left.z);

      curbRVertices.push(right.x, right.y, right.z);
      curbRVertices.push(curbRightOuter.x, curbRightOuter.y, curbRightOuter.z);

      if (i < numSegments) {
        const vIdx = i * 2;
        // Two triangles per road segment
        roadIndices.push(vIdx, vIdx + 1, vIdx + 2);
        roadIndices.push(vIdx + 1, vIdx + 3, vIdx + 2);

        curbIndices.push(vIdx, vIdx + 1, vIdx + 2);
        curbIndices.push(vIdx + 1, vIdx + 3, vIdx + 2);
      }
    }

    // Road Mesh
    const roadGeo = new THREE.BufferGeometry();
    roadGeo.setAttribute('position', new THREE.Float32BufferAttribute(roadVertices, 3));
    roadGeo.setAttribute('uv', new THREE.Float32BufferAttribute(roadUvs, 2));
    roadGeo.setIndex(roadIndices);
    roadGeo.computeVertexNormals();

    const roadMat = new THREE.MeshStandardMaterial({
      color: 0x1a1d24,
      roughness: 0.8,
      metalness: 0.1
    });

    const roadMesh = new THREE.Mesh(roadGeo, roadMat);
    roadMesh.receiveShadow = true;
    this.trackGroup.add(roadMesh);

    // Kerbs (Red & White alternating vertex colors)
    this.createStripedKerb(curbLVertices, curbIndices);
    this.createStripedKerb(curbRVertices, curbIndices);

    // Guardrail barriers along perimeter
    this.buildGuardrails(roadPoints, halfWidth + curbWidth + 0.5);
  }

  createStripedKerb(vertices, indices) {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    geo.setIndex(indices);
    geo.computeVertexNormals();

    const numVerts = vertices.length / 3;
    const colors = [];
    for (let i = 0; i < numVerts; i += 2) {
      const isRed = Math.floor(i / 8) % 2 === 0;
      const r = isRed ? 0.95 : 0.95;
      const g = isRed ? 0.15 : 0.95;
      const b = isRed ? 0.25 : 0.95;
      colors.push(r, g, b);
      colors.push(r, g, b);
    }
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    const mat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.6
    });

    const mesh = new THREE.Mesh(geo, mat);
    mesh.receiveShadow = true;
    this.trackGroup.add(mesh);
  }

  buildGuardrails(points, offsetDistance) {
    const numPts = points.length;
    const railMat = new THREE.MeshStandardMaterial({
      color: 0x4a5568,
      metalness: 0.8,
      roughness: 0.3
    });

    // Guardrail posts and neon chevron signs at sharp corners
    for (let i = 0; i < numPts; i += 6) {
      const u = i / numPts;
      const pt = points[i];
      const tangent = this.curve.getTangentAt(u).normalize();
      const normal = new THREE.Vector3().crossVectors(tangent, new THREE.Vector3(0, 1, 0)).normalize();

      [-offsetDistance, offsetDistance].forEach((offset) => {
        const postPos = new THREE.Vector3().copy(pt).addScaledVector(normal, offset);
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.2, 0.3), railMat);
        post.position.set(postPos.x, 0.6, postPos.z);
        post.castShadow = true;
        this.trackGroup.add(post);
      });
    }
  }

  buildStartGantry() {
    // Overhead starting arch across track at point (0, 0, 0)
    const gantryGroup = new THREE.Group();
    gantryGroup.position.set(0, 0, 5);

    const metalMat = new THREE.MeshStandardMaterial({
      color: 0x2d3748,
      metalness: 0.8,
      roughness: 0.2
    });

    // Left Pillar
    const pillarL = new THREE.Mesh(new THREE.BoxGeometry(0.8, 6, 0.8), metalMat);
    pillarL.position.set(-this.roadWidth / 2 - 2, 3, 0);
    gantryGroup.add(pillarL);

    // Right Pillar
    const pillarR = new THREE.Mesh(new THREE.BoxGeometry(0.8, 6, 0.8), metalMat);
    pillarR.position.set(this.roadWidth / 2 + 2, 3, 0);
    gantryGroup.add(pillarR);

    // Overhead Truss Bar
    const crossBeam = new THREE.Mesh(new THREE.BoxGeometry(this.roadWidth + 4.8, 0.9, 0.8), metalMat);
    crossBeam.position.set(0, 5.8, 0);
    gantryGroup.add(crossBeam);

    // Checkered Start/Finish Line on the Road
    const checkMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    for (let i = 0; i < 12; i++) {
      const x = -this.roadWidth / 2 + (i + 0.5) * (this.roadWidth / 12);
      if (i % 2 === 0) {
        const checker = new THREE.Mesh(new THREE.BoxGeometry(this.roadWidth / 12, 0.08, 1.4), checkMat);
        checker.position.set(x, 0.08, 5);
        this.trackGroup.add(checker);
      }
    }

    // Race Lights on Gantry (Red, Yellow, Green bulbs)
    this.lightBulbs = [];
    const bulbPositions = [-2, 0, 2];
    bulbPositions.forEach((bx) => {
      const bulb = new THREE.Mesh(
        new THREE.SphereGeometry(0.35, 12, 12),
        new THREE.MeshBasicMaterial({ color: 0x330000 })
      );
      bulb.position.set(bx, 5.2, 0);
      gantryGroup.add(bulb);
      this.lightBulbs.push(bulb);
    });

    this.trackGroup.add(gantryGroup);
  }

  setGantryLights(state) {
    // state: 'ready' (all red), 'set' (yellow), 'go' (green), 'off' (dark)
    if (!this.lightBulbs || this.lightBulbs.length < 3) return;

    if (state === 'off') {
      this.lightBulbs.forEach(b => b.material.color.setHex(0x222222));
    } else if (state === '3') {
      this.lightBulbs[0].material.color.setHex(0xff0022);
      this.lightBulbs[1].material.color.setHex(0x222222);
      this.lightBulbs[2].material.color.setHex(0x222222);
    } else if (state === '2') {
      this.lightBulbs[0].material.color.setHex(0xff0022);
      this.lightBulbs[1].material.color.setHex(0xffbb00);
      this.lightBulbs[2].material.color.setHex(0x222222);
    } else if (state === '1') {
      this.lightBulbs[0].material.color.setHex(0xff0022);
      this.lightBulbs[1].material.color.setHex(0xffbb00);
      this.lightBulbs[2].material.color.setHex(0xffbb00);
    } else if (state === 'go') {
      this.lightBulbs.forEach(b => b.material.color.setHex(0x00ff88));
    }
  }

  buildEnvironment() {
    // Terrain Ground Plane
    const groundGeo = new THREE.PlaneGeometry(600, 600);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0c131d,
      roughness: 0.95,
      metalness: 0.05
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = 0;
    ground.receiveShadow = true;
    this.trackGroup.add(ground);

    // Distant Stadium / Skyline blocks & trees
    const treeMat = new THREE.MeshStandardMaterial({ color: 0x142e20, roughness: 0.8 });
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x3d2b1f });

    // Place decorative low-poly trees scattered outside the track
    for (let i = 0; i < 60; i++) {
      const angle = Math.random() * Math.PI * 2;
      const radius = 90 + Math.random() * 150;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;

      // Tree Trunk
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.4, 3, 6), trunkMat);
      trunk.position.set(x, 1.5, z);
      this.trackGroup.add(trunk);

      // Leaves Cone
      const foliage = new THREE.Mesh(new THREE.ConeGeometry(2.2, 5, 6), treeMat);
      foliage.position.set(x, 5.0, z);
      this.trackGroup.add(foliage);
    }
  }

  generateCheckpoints() {
    // 12 equidistant checkpoints along track
    const count = 12;
    this.checkpoints = [];

    for (let i = 0; i < count; i++) {
      const u = i / count;
      const pt = this.curve.getPointAt(u);
      const tangent = this.curve.getTangentAt(u).normalize();
      
      this.checkpoints.push({
        index: i,
        u: u,
        pos: pt,
        tangent: tangent,
        radius: 18 // Trigger radius
      });
    }

    // Starting grid slots: Player 1 (Red) left slot, Player 2 (Cyan) right slot
    const startU = 0.0;
    const startPt = this.curve.getPointAt(startU);
    const startTangent = this.curve.getTangentAt(startU).normalize();
    const startNormal = new THREE.Vector3().crossVectors(startTangent, new THREE.Vector3(0, 1, 0)).normalize();
    const rotY = Math.atan2(startTangent.x, startTangent.z);

    this.startPositions = [
      {
        slot: 1,
        pos: new THREE.Vector3().copy(startPt).addScaledVector(startNormal, -3.2).addScaledVector(startTangent, -3),
        rotY: rotY
      },
      {
        slot: 2,
        pos: new THREE.Vector3().copy(startPt).addScaledVector(startNormal, 3.2).addScaledVector(startTangent, -8),
        rotY: rotY
      }
    ];
  }

  // Check if car passes next checkpoint
  checkCheckpointProgress(carPos, currentCheckpointIdx) {
    const targetIdx = (currentCheckpointIdx + 1) % this.checkpoints.length;
    const target = this.checkpoints[targetIdx];

    const dx = carPos.x - target.pos.x;
    const dz = carPos.z - target.pos.z;
    const distSq = dx * dx + dz * dz;

    if (distSq < target.radius * target.radius) {
      // Passed next checkpoint!
      const isLapComplete = targetIdx === 0 && currentCheckpointIdx === this.checkpoints.length - 1;
      return {
        passed: true,
        newIndex: targetIdx,
        isLapComplete: isLapComplete
      };
    }

    return { passed: false };
  }

  // Barrier bounce and containment: keeps cars on road
  constrainCarToTrack(car) {
    // Find closest point on curve
    let closestU = 0;
    let minDistanceSq = Infinity;
    const samples = 100;

    for (let i = 0; i < samples; i++) {
      const u = i / samples;
      const pt = this.curve.getPointAt(u);
      const dSq = (car.x - pt.x) ** 2 + (car.z - pt.z) ** 2;
      if (dSq < minDistanceSq) {
        minDistanceSq = dSq;
        closestU = u;
      }
    }

    const maxDist = this.roadWidth / 2 + 1.2;
    const currentDist = Math.sqrt(minDistanceSq);

    if (currentDist > maxDist) {
      // Reached guardrail: push car gently inward & slow down
      const pt = this.curve.getPointAt(closestU);
      const toCenter = new THREE.Vector2(pt.x - car.x, pt.z - car.z).normalize();

      car.x += toCenter.x * (currentDist - maxDist);
      car.z += toCenter.y * (currentDist - maxDist);

      // Dampen speed on collision with barrier
      car.speed *= 0.65;
    }
  }

  // --- NITRO BOOST PADS (NITROLAR) ---
  buildNitroPads() {
    this.nitroPads = [];
    const configs = [
      { u: 0.08, offset: 0.0 },   // Main straight
      { u: 0.23, offset: 0.8 },   // Turn 1 exit
      { u: 0.39, offset: -0.8 },  // Short straight before chicane
      { u: 0.58, offset: 0.0 },   // Fast sweeper straight
      { u: 0.75, offset: 0.0 },   // Back sweeper straight
      { u: 0.91, offset: -0.5 }   // Approach to final straight
    ];

    const padMat = new THREE.MeshStandardMaterial({
      color: 0x071e2e,
      emissive: 0x00d2ff,
      emissiveIntensity: 0.5,
      roughness: 0.3,
      metalness: 0.8
    });

    const arrowMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff });
    const canisterMat = new THREE.MeshStandardMaterial({
      color: 0x00f0ff,
      emissive: 0x0088cc,
      emissiveIntensity: 0.6,
      roughness: 0.2,
      metalness: 0.9
    });

    configs.forEach((cfg, idx) => {
      const pt = this.curve.getPointAt(cfg.u);
      const tangent = this.curve.getTangentAt(cfg.u).normalize();
      const normal = new THREE.Vector3().crossVectors(tangent, new THREE.Vector3(0, 1, 0)).normalize();
      const rotY = Math.atan2(tangent.x, tangent.z);

      const pos = new THREE.Vector3().copy(pt).addScaledVector(normal, cfg.offset);
      pos.y = 0.07;

      const group = new THREE.Group();
      group.position.copy(pos);
      group.rotation.y = rotY;

      // 1. Tarmac Boost Chevron Pad
      const padMesh = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.06, 4.6), padMat);
      padMesh.receiveShadow = true;
      group.add(padMesh);

      // Chevron arrow strips
      [-1.0, 0.4, 1.6].forEach((zOff) => {
        const arrowL = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.08, 1.4), arrowMat);
        arrowL.position.set(-0.6, 0.04, zOff);
        arrowL.rotation.y = Math.PI / 4;
        group.add(arrowL);

        const arrowR = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.08, 1.4), arrowMat);
        arrowR.position.set(0.6, 0.04, zOff);
        arrowR.rotation.y = -Math.PI / 4;
        group.add(arrowR);
      });

      // 2. Floating Animated 3D Nitro Canister
      const floatGroup = new THREE.Group();
      floatGroup.position.set(0, 1.6, 0);

      const can = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 1.0, 12), canisterMat);
      floatGroup.add(can);

      // Top and bottom chrome caps
      const capMat = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.9, roughness: 0.1 });
      const topCap = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.15, 12), capMat);
      topCap.position.y = 0.52;
      floatGroup.add(topCap);

      const btmCap = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.15, 12), capMat);
      btmCap.position.y = -0.52;
      floatGroup.add(btmCap);

      // Orbiting Neon Rings
      const ring1 = new THREE.Mesh(new THREE.TorusGeometry(0.68, 0.04, 6, 18), ringMat);
      ring1.rotation.x = Math.PI / 3;
      floatGroup.add(ring1);

      const ring2 = new THREE.Mesh(new THREE.TorusGeometry(0.68, 0.04, 6, 18), ringMat);
      ring2.rotation.y = Math.PI / 3;
      floatGroup.add(ring2);

      group.add(floatGroup);
      this.trackGroup.add(group);

      this.nitroPads.push({
        id: `nitro_${idx}`,
        u: cfg.u,
        pos: pos,
        group: group,
        floatGroup: floatGroup,
        ring1: ring1,
        ring2: ring2,
        active: true,
        cooldownTimer: 0,
        radius: 2.8,
        time: Math.random() * 10
      });
    });
  }

  // --- OBSTACLES (TO'SIQ BOCHKALARI) ---
  buildObstacles() {
    this.obstacles = [];
    const configs = [
      { u: 0.16, offset: 2.2 },   // Turn 1 right apex
      { u: 0.32, offset: -2.5 },  // Chicane entry left
      { u: 0.46, offset: 0.0 },   // Mid-chicane center road block
      { u: 0.65, offset: 2.4 },   // Fast sweeper outside
      { u: 0.83, offset: -2.0 }   // Hairpin entry left apex
    ];

    const barrelMat1 = new THREE.MeshStandardMaterial({
      color: 0xff5500,
      roughness: 0.4,
      metalness: 0.3
    });
    const barrelMat2 = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.4,
      metalness: 0.2
    });
    const beaconMat = new THREE.MeshBasicMaterial({ color: 0xffaa00 });

    configs.forEach((cfg, idx) => {
      const pt = this.curve.getPointAt(cfg.u);
      const tangent = this.curve.getTangentAt(cfg.u).normalize();
      const normal = new THREE.Vector3().crossVectors(tangent, new THREE.Vector3(0, 1, 0)).normalize();
      const rotY = Math.atan2(tangent.x, tangent.z);

      const pos = new THREE.Vector3().copy(pt).addScaledVector(normal, cfg.offset);

      const group = new THREE.Group();
      group.position.set(pos.x, 0, pos.z);
      group.rotation.y = rotY;

      // 3D Industrial Hazard Barrier Barrel
      const barrel = new THREE.Group();
      barrel.position.y = 0.6;

      // Tiered stripes
      const segH = 0.3;
      for (let s = 0; s < 4; s++) {
        const mat = (s % 2 === 0) ? barrelMat1 : barrelMat2;
        const tier = new THREE.Mesh(new THREE.CylinderGeometry(0.52 - s * 0.02, 0.55 - s * 0.02, segH, 12), mat);
        tier.position.y = (s - 1.5) * segH;
        tier.castShadow = true;
        tier.receiveShadow = true;
        barrel.add(tier);
      }

      // Top flashing warning beacon
      const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 8), beaconMat);
      beacon.position.y = 0.75;
      barrel.add(beacon);

      // Base weight plate
      const basePlate = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.7, 0.1, 12), barrelMat1);
      basePlate.position.y = -0.55;
      barrel.add(basePlate);

      group.add(barrel);
      this.trackGroup.add(group);

      this.obstacles.push({
        id: `obs_${idx}`,
        u: cfg.u,
        pos: pos,
        group: group,
        barrel: barrel,
        beacon: beacon,
        active: true,
        cooldownTimer: 0,
        radius: 1.9,
        baseY: 0.6
      });
    });
  }

  // --- OIL SLICKS (MOY TO'SIQLARI) ---
  buildOilSlicks() {
    this.oilSlicks = [];
    const configs = [
      { u: 0.28, offset: -1.6 }, // Turn 2 apex
      { u: 0.52, offset: 1.4 },  // Sweeper middle-right
      { u: 0.86, offset: 0.3 }   // Hairpin exit
    ];

    const oilMat = new THREE.MeshStandardMaterial({
      color: 0x090614,
      roughness: 0.08,
      metalness: 0.95
    });

    configs.forEach((cfg, idx) => {
      const pt = this.curve.getPointAt(cfg.u);
      const tangent = this.curve.getTangentAt(cfg.u).normalize();
      const normal = new THREE.Vector3().crossVectors(tangent, new THREE.Vector3(0, 1, 0)).normalize();
      const rotY = Math.atan2(tangent.x, tangent.z);

      const pos = new THREE.Vector3().copy(pt).addScaledVector(normal, cfg.offset);
      pos.y = 0.06;

      const group = new THREE.Group();
      group.position.copy(pos);
      group.rotation.y = rotY;

      // Dark puddle with irregular shape
      const puddle = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 2.3, 0.03, 14), oilMat);
      puddle.scale.set(1.0, 1.0, 1.4); // Stretched along road
      puddle.receiveShadow = true;
      group.add(puddle);

      this.trackGroup.add(group);

      this.oilSlicks.push({
        id: `oil_${idx}`,
        u: cfg.u,
        pos: pos,
        radius: 2.4
      });
    });
  }

  // --- PER-FRAME ANIMATION & TIMERS ---
  update(dt) {
    // 1. Animate Nitro Boost Pads
    if (this.nitroPads) {
      this.nitroPads.forEach(pad => {
        pad.time += dt;
        if (pad.active) {
          pad.floatGroup.visible = true;
          pad.floatGroup.position.y = 1.5 + Math.sin(pad.time * 3.5) * 0.25;
          pad.floatGroup.rotation.y += dt * 2.8;
          pad.ring1.rotation.x += dt * 3.0;
          pad.ring2.rotation.z += dt * 2.5;
        } else {
          pad.cooldownTimer -= dt;
          pad.floatGroup.visible = false;
          if (pad.cooldownTimer <= 0) {
            pad.active = true;
            pad.floatGroup.visible = true;
          }
        }
      });
    }

    // 2. Animate Obstacles
    if (this.obstacles) {
      const blink = Math.sin(performance.now() * 0.008) > 0;
      this.obstacles.forEach(obs => {
        obs.beacon.material.color.setHex(blink ? 0xffaa00 : 0x552200);

        if (!obs.active) {
          obs.cooldownTimer -= dt;
          if (obs.cooldownTimer <= 0) {
            obs.active = true;
            obs.barrel.position.y = obs.baseY;
            obs.barrel.rotation.set(0, 0, 0);
          }
        }
      });
    }
  }

  // --- CHECK INTERACTIONS (LOCAL CAR WITH NITRO / OBSTACLES) ---
  checkCarInteractions(car) {
    if (!car) return [];
    const interactions = [];

    // Check Nitro Pads
    if (this.nitroPads) {
      for (const pad of this.nitroPads) {
        if (!pad.active) continue;
        const dx = car.x - pad.pos.x;
        const dz = car.z - pad.pos.z;
        const distSq = dx * dx + dz * dz;
        if (distSq < pad.radius * pad.radius) {
          pad.active = false;
          pad.cooldownTimer = 4.0; // 4s respawn
          interactions.push({ type: 'nitro', id: pad.id, pos: pad.pos });
        }
      }
    }

    // Check Obstacles
    if (this.obstacles) {
      for (const obs of this.obstacles) {
        if (!obs.active) continue;
        const dx = car.x - obs.pos.x;
        const dz = car.z - obs.pos.z;
        const distSq = dx * dx + dz * dz;
        if (distSq < obs.radius * obs.radius) {
          obs.active = false;
          obs.cooldownTimer = 4.5; // 4.5s respawn
          // Knock barrel over
          obs.barrel.position.y = 0.2;
          obs.barrel.rotation.z = Math.PI / 2.5;
          interactions.push({ type: 'obstacle', id: obs.id, pos: obs.pos });
        }
      }
    }

    // Check Oil Slicks
    if (this.oilSlicks && (!car.oilCooldown || car.oilCooldown <= 0)) {
      for (const oil of this.oilSlicks) {
        const dx = car.x - oil.pos.x;
        const dz = car.z - oil.pos.z;
        const distSq = dx * dx + dz * dz;
        if (distSq < oil.radius * oil.radius) {
          car.oilCooldown = 1.8; // immunity cooldown
          interactions.push({ type: 'oil', id: oil.id, pos: oil.pos });
          break;
        }
      }
    }

    return interactions;
  }

  // Render 2D top-down minimap on HUD canvas with track, cars, nitro & obstacles
  renderMinimap(canvas, p1Car, p2Car) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    // Coordinate mapping bounds
    const minX = -120, maxX = 160;
    const minZ = -140, maxZ = 160;

    const mapX = (x) => ((x - minX) / (maxX - minX)) * (w - 24) + 12;
    const mapY = (z) => ((z - minZ) / (maxZ - minZ)) * (h - 24) + 12;

    // Draw Track Path
    ctx.beginPath();
    ctx.strokeStyle = '#22324e';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const points = this.curve.getPoints(80);
    points.forEach((pt, i) => {
      const px = mapX(pt.x);
      const py = mapY(pt.z);
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.closePath();
    ctx.stroke();

    // Inner bright neon line
    ctx.beginPath();
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 2;
    points.forEach((pt, i) => {
      const px = mapX(pt.x);
      const py = mapY(pt.z);
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.closePath();
    ctx.stroke();

    // Start/Finish indicator
    const startPt = this.curve.getPointAt(0);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(mapX(startPt.x), mapY(startPt.z), 3, 0, Math.PI * 2);
    ctx.fill();

    // Draw Nitro Pads (cyan glowing diamonds)
    if (this.nitroPads) {
      this.nitroPads.forEach(pad => {
        if (pad.active) {
          const nx = mapX(pad.pos.x);
          const ny = mapY(pad.pos.z);
          ctx.fillStyle = '#00f0ff';
          ctx.beginPath();
          ctx.moveTo(nx, ny - 3.5);
          ctx.lineTo(nx + 3.5, ny);
          ctx.lineTo(nx, ny + 3.5);
          ctx.lineTo(nx - 3.5, ny);
          ctx.closePath();
          ctx.fill();
        }
      });
    }

    // Draw Obstacles (orange warning dots)
    if (this.obstacles) {
      this.obstacles.forEach(obs => {
        if (obs.active) {
          const ox = mapX(obs.pos.x);
          const oy = mapY(obs.pos.z);
          ctx.fillStyle = '#ff6600';
          ctx.beginPath();
          ctx.arc(ox, oy, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      });
    }

    // Draw Oil Slicks (purple circles)
    if (this.oilSlicks) {
      this.oilSlicks.forEach(oil => {
        const ox = mapX(oil.pos.x);
        const oy = mapY(oil.pos.z);
        ctx.fillStyle = '#9d4edd';
        ctx.beginPath();
        ctx.arc(ox, oy, 2.0, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    // Draw Player 1 (Red dot)
    if (p1Car) {
      ctx.fillStyle = '#ff2b56';
      ctx.shadowColor = '#ff2b56';
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(mapX(p1Car.x), mapY(p1Car.z), 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    // Draw Player 2 (Cyan dot)
    if (p2Car) {
      ctx.fillStyle = '#00ff88';
      ctx.shadowColor = '#00ff88';
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(mapX(p2Car.x), mapY(p2Car.z), 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }
  }
}

window.RaceTrack = RaceTrack;
