/**
 * APEX SPEED 3D - Main Game Loop & UI Orchestrator
 * High-performance WebGL renderer, dynamic chase camera, HUD telemetry, and rematch state machine
 */

class GameApp {
  constructor() {
    this.container = document.getElementById('canvas-container');
    this.state = 'LOBBY'; // 'LOBBY' | 'COUNTDOWN' | 'RACING' | 'FINISHED'
    
    this.scene = null;
    this.camera = null;
    this.renderer = null;

    this.track = null;
    this.localCar = null;
    this.remoteCar = null;

    this.role = 'p1'; // 'p1' | 'p2'
    this.isSolo = false;
    this.lapsTotal = 2;
    this.currentLap = 1;
    this.currentCheckpoint = 0;
    this.opponentLap = 1;
    this.opponentCheckpoint = 0;

    // Timing
    this.clock = new THREE.Clock();
    this.raceStartTime = 0;
    this.lapStartTime = 0;
    this.bestLapTime = Infinity;
    this.totalRaceTime = 0;

    // Network throttle (25 updates/sec = 40ms interval)
    this.lastNetSendTime = 0;
    this.netSendInterval = 0.04;

    // FPS calculation
    this.frameCount = 0;
    this.lastFpsUpdate = 0;
    this.currentFps = 60;

    // Outgoing/Incoming Challenge Tracking
    this.challengeTimeoutId = null;
    this.challengeProgressInterval = null;

    this.initThree();
    this.initEventListeners();
    this.animate();
  }

  initThree() {
    // 1. Scene & Atmospheric Lighting
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0e17);
    this.scene.fog = new THREE.FogExp2(0x0a0e17, 0.004);

    // 2. Camera
    const aspect = window.innerWidth / window.innerHeight;
    this.camera = new THREE.PerspectiveCamera(60, aspect, 0.5, 800);
    this.camera.position.set(0, 15, -25);

    // 3. Renderer (Optimized for mobile: powerPreference high-performance, max 2.0 pixelRatio)
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2.0));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.container.appendChild(this.renderer.domElement);

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0x5a6d8a, 0.8);
    this.scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff5e6, 1.2);
    sunLight.position.set(80, 120, 60);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 300;
    sunLight.shadow.camera.left = -100;
    sunLight.shadow.camera.right = 100;
    sunLight.shadow.camera.top = 100;
    sunLight.shadow.camera.bottom = -100;
    this.scene.add(sunLight);

    // 5. Build Procedural Race Track
    this.track = new RaceTrack(this.scene);

    // Handle Window Resize
    window.addEventListener('resize', () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });
  }

  initEventListeners() {
    // Player Name Change
    const nameInput = document.getElementById('player-name-input');
    if (nameInput) {
      nameInput.addEventListener('change', (e) => {
        window.networkManager.setName(e.target.value);
      });
    }

    // Solo Practice Button
    const soloBtn = document.getElementById('btn-solo-practice');
    if (soloBtn) {
      soloBtn.addEventListener('click', () => {
        window.soundEngine.unlock();
        window.networkManager.startSoloPractice();
      });
    }

    // Rematch Button
    const rematchBtn = document.getElementById('btn-rematch');
    if (rematchBtn) {
      rematchBtn.addEventListener('click', () => {
        rematchBtn.disabled = true;
        rematchBtn.textContent = 'Kutilmoqda... (1/2)';
        window.networkManager.sendRematchVote();
      });
    }

    // Exit to Lobby Button
    const exitBtn = document.getElementById('btn-exit-lobby');
    if (exitBtn) {
      exitBtn.addEventListener('click', () => {
        window.networkManager.leaveRoom();
        this.returnToLobby();
      });
    }
  }

  // --- LOBBY PLAYERS RENDERING ---
  renderLobbyPlayers(playersList, myId) {
    const listEl = document.getElementById('lobby-players-list');
    const countEl = document.getElementById('online-count-badge');
    if (!listEl) return;

    if (countEl) countEl.textContent = `${playersList.length} Online`;

    listEl.innerHTML = '';

    const otherPlayers = playersList.filter(p => p.id !== myId);

    if (otherPlayers.length === 0) {
      listEl.innerHTML = `
        <div class="no-players">
          Hozircha serverda boshqa o'yinchi yo'q.<br>
          Do'stingizga linkni yuboring yoki <b>Solo Practice</b> qiling!
        </div>
      `;
      return;
    }

    otherPlayers.forEach(p => {
      const item = document.createElement('div');
      item.className = 'player-item';

      let statusBadge = '';
      let actionBtn = '';

      if (p.status === 'lobby') {
        statusBadge = `<span class="status-badge lobby">Online</span>`;
        actionBtn = `<button class="btn-challenge" onclick="window.gameApp.onChallengeClick('${p.id}')">⚔️ Challenge</button>`;
      } else if (p.status === 'in_race') {
        statusBadge = `<span class="status-badge in_race">Poygada</span>`;
        actionBtn = `<button class="btn-challenge" disabled>Band</button>`;
      } else {
        statusBadge = `<span class="status-badge challenging">Kutmoqda</span>`;
        actionBtn = `<button class="btn-challenge" disabled>Band</button>`;
      }

      item.innerHTML = `
        <div class="player-item-info">
          <div class="avatar-circle">🏎️</div>
          <div>
            <div class="player-name-text">${this.escapeHtml(p.name)}</div>
            ${statusBadge}
          </div>
        </div>
        ${actionBtn}
      `;
      listEl.appendChild(item);
    });
  }

  escapeHtml(str) {
    const div = document.createElement('div');
    div.innerText = str;
    return div.innerHTML;
  }

  onChallengeClick(targetId) {
    window.soundEngine.unlock();
    window.networkManager.sendChallenge(targetId);
  }

  showOutgoingChallengeModal(msg) {
    const modal = document.getElementById('outgoing-challenge-modal');
    const targetNameEl = document.getElementById('outgoing-target-name');
    const cancelBtn = document.getElementById('btn-cancel-outgoing');
    const bar = document.getElementById('outgoing-countdown-bar');

    if (targetNameEl) targetNameEl.textContent = msg.targetName;
    if (modal) modal.classList.remove('hidden');

    if (bar) {
      bar.style.transition = 'none';
      bar.style.width = '100%';
      setTimeout(() => {
        bar.style.transition = 'width 15s linear';
        bar.style.width = '0%';
      }, 50);
    }

    if (cancelBtn) {
      cancelBtn.onclick = () => {
        window.networkManager.cancelChallenge(msg.challengeId);
        this.hideChallengeModals();
      };
    }
  }

  showIncomingChallengeModal(msg) {
    window.soundEngine.unlock();
    window.soundEngine.playCountdown(3);

    const modal = document.getElementById('incoming-challenge-modal');
    const senderNameEl = document.getElementById('incoming-sender-name');
    const acceptBtn = document.getElementById('btn-accept-challenge');
    const declineBtn = document.getElementById('btn-decline-challenge');
    const bar = document.getElementById('incoming-countdown-bar');

    if (senderNameEl) senderNameEl.textContent = msg.fromName;
    if (modal) modal.classList.remove('hidden');

    if (bar) {
      bar.style.transition = 'none';
      bar.style.width = '100%';
      setTimeout(() => {
        bar.style.transition = 'width 15s linear';
        bar.style.width = '0%';
      }, 50);
    }

    if (acceptBtn) {
      acceptBtn.onclick = () => {
        window.networkManager.acceptChallenge(msg.challengeId);
        this.hideChallengeModals();
      };
    }

    if (declineBtn) {
      declineBtn.onclick = () => {
        window.networkManager.declineChallenge(msg.challengeId);
        this.hideChallengeModals();
      };
    }
  }

  hideChallengeModals() {
    const incoming = document.getElementById('incoming-challenge-modal');
    const outgoing = document.getElementById('outgoing-challenge-modal');
    if (incoming) incoming.classList.add('hidden');
    if (outgoing) outgoing.classList.add('hidden');
  }

  // --- RACE SESSION INITIALIZATION ---
  startRaceSession(config) {
    this.hideChallengeModals();
    this.state = 'COUNTDOWN';
    this.role = config.role;
    this.isSolo = !!config.isSolo;
    this.lapsTotal = config.lapsTotal || 2;
    this.currentLap = 1;
    this.currentCheckpoint = 0;
    this.opponentLap = 1;
    this.opponentCheckpoint = 0;

    // Switch UI Screens
    const lobbyScreen = document.getElementById('lobby-screen');
    const hudOverlay = document.getElementById('hud-overlay');
    const resultsModal = document.getElementById('results-modal');
    if (lobbyScreen) lobbyScreen.style.display = 'none';
    if (resultsModal) resultsModal.classList.add('hidden');
    if (hudOverlay) hudOverlay.classList.remove('hidden');

    // Clean up previous cars if any
    if (this.localCar) this.localCar.dispose();
    if (this.remoteCar) this.remoteCar.dispose();

    // Spawn Local Car
    const myColor = config.color; // 'red' or 'cyan'
    this.localCar = new Car(this.scene, myColor, false);

    const slotIdx = (config.gridSlot || 1) - 1;
    const startData = this.track.startPositions[slotIdx];
    this.localCar.resetPosition(startData.pos.x, startData.pos.y, startData.pos.z, startData.rotY);

    // Spawn Remote Opponent Car (if multiplayer)
    if (!this.isSolo) {
      const oppColor = myColor === 'red' ? 'cyan' : 'red';
      this.remoteCar = new Car(this.scene, oppColor, true);

      const oppSlotIdx = slotIdx === 0 ? 1 : 0;
      const oppStartData = this.track.startPositions[oppSlotIdx];
      this.remoteCar.resetPosition(oppStartData.pos.x, oppStartData.pos.y, oppStartData.pos.z, oppStartData.rotY);
    } else {
      this.remoteCar = null;
    }

    // Lock input during countdown
    window.inputController.lock();

    // Reset Gantry lights
    this.track.setGantryLights('off');

    // Notify server we are ready
    window.networkManager.sendClientReady(config.roomId);
  }

  onCountdownTick(count, text) {
    const cdEl = document.getElementById('countdown-screen');
    if (!cdEl) return;

    cdEl.textContent = text;
    cdEl.className = 'active';

    if (count > 0) {
      window.soundEngine.playCountdown(count);
      this.track.setGantryLights(`${count}`);
    } else {
      // GO!
      cdEl.classList.add('go');
      window.soundEngine.playCountdown(0);
      this.track.setGantryLights('go');

      this.state = 'RACING';
      this.raceStartTime = performance.now();
      this.lapStartTime = performance.now();
      window.inputController.unlock();

      // Fade out countdown text after 1s
      setTimeout(() => {
        cdEl.className = '';
        this.track.setGantryLights('off');
      }, 1000);
    }
  }

  onOpponentCarUpdate(data) {
    // data = [x, y, z, rotY, steer, speed, isDrift, isNitro]
    if (this.remoteCar && data) {
      this.remoteCar.setRemoteState(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7]);
    }
  }

  onOpponentProgress(cpIndex, lap) {
    this.opponentCheckpoint = cpIndex;
    this.opponentLap = lap;
  }

  onOpponentFinished(msg) {
    // Opponent finished ahead of us (or finished their race)
  }

  onRaceEnded(msg) {
    this.state = 'FINISHED';
    window.inputController.lock();

    if (window.soundEngine) {
      window.soundEngine.stopEngine();
      if (msg.isWinner) window.soundEngine.playWin();
    }

    const modal = document.getElementById('results-modal');
    const title = document.getElementById('results-title');
    const winnerNameEl = document.getElementById('results-winner-name');
    const totalTimeEl = document.getElementById('results-total-time');
    const bestLapEl = document.getElementById('results-best-lap');
    const rematchBtn = document.getElementById('btn-rematch');
    const rematchStatus = document.getElementById('rematch-status-pill');

    if (title) {
      title.textContent = msg.isWinner ? '🏆 VICTORY!' : '🏁 2ND PLACE';
      title.style.color = msg.isWinner ? '#ffbe0b' : '#00f0ff';
    }

    if (winnerNameEl) {
      winnerNameEl.textContent = msg.isWinner ? 'Siz g\'olib bo\'ldingiz!' : `${msg.winnerName || 'Raqib'} g'olib bo'ldi!`;
    }

    if (totalTimeEl) totalTimeEl.textContent = this.formatTime(msg.totalTime || this.totalRaceTime);
    if (bestLapEl) bestLapEl.textContent = this.formatTime(this.bestLapTime === Infinity ? (msg.totalTime / 2) : this.bestLapTime);

    if (rematchBtn) {
      rematchBtn.disabled = false;
      rematchBtn.textContent = '🔄 Rematch (0/2)';
    }

    if (rematchStatus) {
      rematchStatus.textContent = 'Rematch kutilyapti...';
    }

    if (modal) modal.classList.remove('hidden');
  }

  updateRematchStatus(votes, needed, votedBy) {
    const rematchBtn = document.getElementById('btn-rematch');
    const rematchStatus = document.getElementById('rematch-status-pill');
    if (rematchBtn && rematchBtn.disabled) {
      rematchBtn.textContent = `Kutilmoqda... (${votes}/${needed})`;
    }
    if (rematchStatus) {
      rematchStatus.textContent = `${votedBy} qayta o'ynashga tayyor! (${votes}/${needed})`;
    }
  }

  resetForRematch() {
    const modal = document.getElementById('results-modal');
    if (modal) modal.classList.add('hidden');

    this.state = 'COUNTDOWN';
    this.currentLap = 1;
    this.currentCheckpoint = 0;
    this.opponentLap = 1;
    this.opponentCheckpoint = 0;

    // Reset local car
    const slotIdx = (this.role === 'p1' ? 1 : 2) - 1;
    const startData = this.track.startPositions[slotIdx];
    this.localCar.resetPosition(startData.pos.x, startData.pos.y, startData.pos.z, startData.rotY);

    // Reset remote car
    if (this.remoteCar) {
      const oppSlotIdx = slotIdx === 0 ? 1 : 0;
      const oppStartData = this.track.startPositions[oppSlotIdx];
      this.remoteCar.resetPosition(oppStartData.pos.x, oppStartData.pos.y, oppStartData.pos.z, oppStartData.rotY);
    }

    window.inputController.lock();
    this.track.setGantryLights('off');
  }

  returnToLobby() {
    this.state = 'LOBBY';
    window.inputController.lock();
    if (window.soundEngine) window.soundEngine.stopEngine();

    const lobbyScreen = document.getElementById('lobby-screen');
    const hudOverlay = document.getElementById('hud-overlay');
    const resultsModal = document.getElementById('results-modal');

    if (lobbyScreen) lobbyScreen.style.display = 'flex';
    if (hudOverlay) hudOverlay.classList.add('hidden');
    if (resultsModal) resultsModal.classList.add('hidden');

    if (this.localCar) {
      this.localCar.dispose();
      this.localCar = null;
    }
    if (this.remoteCar) {
      this.remoteCar.dispose();
      this.remoteCar = null;
    }
  }

  formatTime(ms) {
    if (!ms || ms === Infinity) return '--:--.---';
    const totalSec = ms / 1000;
    const min = Math.floor(totalSec / 60);
    const sec = Math.floor(totalSec % 60);
    const millis = Math.floor((totalSec % 1) * 1000);
    return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}.${millis.toString().padStart(3, '0')}`;
  }

  // --- MAIN ANIMATION & RENDER LOOP ---
  animate() {
    requestAnimationFrame(() => this.animate());

    const dt = Math.min(this.clock.getDelta(), 0.1);
    const now = performance.now();

    // FPS Meter
    this.frameCount++;
    if (now - this.lastFpsUpdate >= 500) {
      this.currentFps = Math.round((this.frameCount * 1000) / (now - this.lastFpsUpdate));
      this.frameCount = 0;
      this.lastFpsUpdate = now;
      const fpsEl = document.getElementById('hud-fps');
      if (fpsEl) fpsEl.textContent = `FPS: ${this.currentFps}`;
    }

    if (this.state === 'LOBBY') {
      // Aesthetic orbit camera around track start line
      const t = now * 0.0003;
      this.camera.position.x = Math.sin(t) * 40;
      this.camera.position.z = Math.cos(t) * 40 + 20;
      this.camera.position.y = 18;
      this.camera.lookAt(0, 2, 20);
    } else {
      // In-Game Update
      if (this.track && this.track.update) {
        this.track.update(dt);
      }

      if (this.localCar) {
        // Car Reset key [R]
        if (window.inputController.reset) {
          const cp = this.track.checkpoints[this.currentCheckpoint];
          if (cp) {
            const rotY = Math.atan2(cp.tangent.x, cp.tangent.z);
            this.localCar.resetPosition(cp.pos.x, 0, cp.pos.z, rotY);
          }
          window.inputController.reset = false;
        }

        this.localCar.update(dt, window.inputController);
        this.track.constrainCarToTrack(this.localCar);

        // Check Nitro & Obstacles interactions
        if (this.state === 'RACING') {
          const interactions = this.track.checkCarInteractions(this.localCar);
          if (interactions && interactions.length > 0) {
            interactions.forEach(inter => {
              if (inter.type === 'nitro') {
                this.localCar.applyNitro();
                if (window.soundEngine) window.soundEngine.playNitro();
                this.showHudAlert('⚡ NITRO BOOST! +160 KM/H', 'nitro');
              } else if (inter.type === 'obstacle') {
                this.localCar.applyObstacleHit();
                if (window.soundEngine) window.soundEngine.playCrash();
                this.showHudAlert('⚠️ TO\'SIQ! -50% TEZLIK', 'obstacle');
              } else if (inter.type === 'oil') {
                this.localCar.applyOilSlick();
                if (window.soundEngine) window.soundEngine.playOilSpin();
                this.showHudAlert('🛢️ MOY TO\'SIQ! SIRPANISH', 'oil');
              }
            });
          }
        }

        // Checkpoint & Lap Detection
        if (this.state === 'RACING') {
          const cpResult = this.track.checkCheckpointProgress(
            { x: this.localCar.x, z: this.localCar.z },
            this.currentCheckpoint
          );

          if (cpResult.passed) {
            this.currentCheckpoint = cpResult.newIndex;
            window.soundEngine.playCheckpoint();

            if (cpResult.isLapComplete) {
              const currentLapTime = now - this.lapStartTime;
              if (currentLapTime < this.bestLapTime) {
                this.bestLapTime = currentLapTime;
              }
              this.lapStartTime = now;

              if (this.currentLap >= this.lapsTotal) {
                // Completed final lap!
                this.totalRaceTime = now - this.raceStartTime;
                window.networkManager.sendRaceFinish(this.totalRaceTime, this.bestLapTime);
              } else {
                this.currentLap++;
              }
            }

            window.networkManager.sendCheckpointPass(this.currentCheckpoint, this.currentLap);
          }
        }

        // Network telemetry relay (25Hz)
        if (this.state === 'RACING' && !this.isSolo && (now - this.lastNetSendTime >= this.netSendInterval * 1000)) {
          this.lastNetSendTime = now;
          window.networkManager.sendCarUpdate([
            Math.round(this.localCar.x * 100) / 100,
            Math.round(this.localCar.y * 100) / 100,
            Math.round(this.localCar.z * 100) / 100,
            Math.round(this.localCar.rotY * 1000) / 1000,
            Math.round(this.localCar.steerAngle * 100) / 100,
            Math.round(this.localCar.speed * 10) / 10,
            this.localCar.isDrifting ? 1 : 0,
            this.localCar.isNitro ? 1 : 0
          ]);
        }
      }

      if (this.remoteCar) {
        this.remoteCar.update(dt, null);
      }

      // Smooth Dynamic Chase Camera
      if (this.localCar) {
        const carX = this.localCar.x;
        const carZ = this.localCar.z;
        const rotY = this.localCar.rotY;

        // Camera distance & height with speed dynamic FOV
        const speedRatio = Math.abs(this.localCar.speed) / this.localCar.maxSpeed;
        const camDistance = 8.5 + speedRatio * 1.5;
        const camHeight = 3.6 + speedRatio * 0.5;

        const targetCamX = carX - Math.sin(rotY) * camDistance;
        const targetCamZ = carZ - Math.cos(rotY) * camDistance;
        const targetCamY = camHeight;

        // Smooth camera damping
        const camLerp = Math.min(1.0, 10.0 * dt);
        this.camera.position.x += (targetCamX - this.camera.position.x) * camLerp;
        this.camera.position.y += (targetCamY - this.camera.position.y) * camLerp;
        this.camera.position.z += (targetCamZ - this.camera.position.z) * camLerp;

        // Look slightly ahead of car
        const lookAhead = 7.0;
        const lookTarget = new THREE.Vector3(
          carX + Math.sin(rotY) * lookAhead,
          0.8,
          carZ + Math.cos(rotY) * lookAhead
        );
        this.camera.lookAt(lookTarget);

        // Speed dynamic FOV (widened during Nitro for warp sensation)
        const baseFov = this.localCar.isNitro ? 78 : 60;
        const targetFov = baseFov + speedRatio * 14;
        this.camera.fov += (targetFov - this.camera.fov) * 6.0 * dt;
        this.camera.updateProjectionMatrix();
      }

      // Update HUD Elements
      this.updateHUD();
    }

    this.renderer.render(this.scene, this.camera);
  }

  showHudAlert(text, type) {
    const alertEl = document.getElementById('hud-alert-banner');
    if (!alertEl) return;
    alertEl.textContent = text;
    alertEl.className = `hud-alert-banner active ${type}`;
    if (this.alertTimeout) clearTimeout(this.alertTimeout);
    this.alertTimeout = setTimeout(() => {
      alertEl.className = 'hud-alert-banner hidden';
    }, 1400);
  }

  updateHUD() {
    if (!this.localCar) return;

    // Speedometer
    const speedKmh = Math.round(Math.abs(this.localCar.speed * 3.6));
    const speedEl = document.getElementById('hud-speed-val');
    const gearEl = document.getElementById('hud-gear-val');
    if (speedEl) speedEl.textContent = speedKmh;

    if (gearEl) {
      if (this.localCar.speed < -0.5) gearEl.textContent = 'GEAR: R';
      else if (this.localCar.isNitro) gearEl.textContent = 'NITRO 🔥';
      else if (speedKmh < 5) gearEl.textContent = 'GEAR: N';
      else if (speedKmh < 45) gearEl.textContent = 'GEAR: 1';
      else if (speedKmh < 85) gearEl.textContent = 'GEAR: 2';
      else if (speedKmh < 125) gearEl.textContent = 'GEAR: 3';
      else gearEl.textContent = 'GEAR: 4';
    }

    // Nitro Gauge
    const nitroFill = document.getElementById('hud-nitro-fill');
    const nitroWrap = document.getElementById('hud-nitro-wrap');
    if (nitroFill) {
      const nitroRatio = Math.max(0, Math.min(1.0, this.localCar.nitroTimer / this.localCar.nitroDuration));
      nitroFill.style.width = `${(nitroRatio * 100).toFixed(1)}%`;
      if (nitroWrap) {
        if (this.localCar.isNitro) {
          nitroWrap.classList.add('active');
        } else {
          nitroWrap.classList.remove('active');
        }
      }
    }

    // Lap Badge
    const lapEl = document.getElementById('hud-lap-badge');
    if (lapEl) {
      lapEl.textContent = `LAP ${Math.min(this.currentLap, this.lapsTotal)} / ${this.lapsTotal}`;
    }

    // Position Calculation (1st vs 2nd)
    const posBadge = document.getElementById('hud-position-badge');
    if (posBadge) {
      if (this.isSolo) {
        posBadge.textContent = 'SOLO';
      } else {
        const myScore = this.currentLap * 100 + this.currentCheckpoint;
        const oppScore = this.opponentLap * 100 + this.opponentCheckpoint;
        const isFirst = myScore >= oppScore;
        posBadge.textContent = isFirst ? '1ST' : '2ND';
        posBadge.style.color = isFirst ? '#ffbe0b' : '#00f0ff';
        posBadge.style.borderColor = isFirst ? '#ffbe0b' : '#00f0ff';
      }
    }

    // Render Minimap
    const mapCanvas = document.getElementById('minimap-canvas');
    if (mapCanvas && this.track) {
      this.track.renderMinimap(mapCanvas, this.localCar, this.remoteCar);
    }
  }
}

// Bootstrap on DOM Load
window.addEventListener('DOMContentLoaded', () => {
  window.gameApp = new GameApp();
  window.networkManager.connect();
});
